

<?php $__env->startSection('content'); ?>

<header id="cheers-alkaline" class="cheers-product">
    <div id="slide-carousel" class="owl-carousel">
        <?php $j=1; ?>
        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $left): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="set-<?php echo e($j); ?>">
            <div class="img-overlay">
                <div class="cheers-bg-product cheers-bgp-<?php echo e($j); ?>" style="
                background: url('<?php echo e($baseurl.$left['background']); ?>') no-repeat;">
                </div>
            </div>
            <div class="row d-flex g-0 heropro-type">
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 pro-leftsection">
                    <div class="bg-imgHero">
                        <div class="owl-carousel1">
                            <div class="content-left">
                                <div class="content-text">
                                    <div class="title-cheproduct">
                                        <h3><?php echo e($left['typeName']); ?> (<?php echo e($left['volume']); ?>)</h3>
                                    </div>
                                    
                                    <p><?php echo e($left['desc_'.$locale]); ?></p>
                                </div>

                                <div class="content-img">
                                    <img src="<?php echo e($baseurl.$left['image']); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 pro-rightsection">
                    <div class="content-right">
                        <div class="content-point align-self-center">
                            <div class="title-product">
                                <h3><?php echo e($left['productName']); ?></h3>
                                <p><?php echo e($left['subtitle_'.$locale]); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $j++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row g-0 card-listproduct">
        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $right): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-cheersproduct" style="background: url('<?php echo e($baseurl.$right['background']); ?>') no-repeat;">
            <div class="overlay-card"></div>
            <div class="row g-0 textpro-card">
                <div class="col-7 textpro-left">
                    <h6><?php echo e($right['typeName']); ?></h6>
                    <h5><?php echo e($right['volume']); ?></h5>
                    <p><?php echo e($right['productName']); ?></p>
                </div>
                <div class="col-5 textpro-right">
                    <img src="<?php echo e($baseurl.$right['image']); ?>">
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</header>

<section id="why-product" class="why-theproduct why-alkaline">
    <div class="title-section-ct">
        <h3><?php echo app('translator')->get('cheers-alkaline.alkaline-whyAlkaline'); ?></h3>
        <hr class="cheers-separator-center">
        <span><?php echo e($head[0]['why_'.$locale]); ?></span>
    </div>

    <div class="container text-center">
        <img src="<?php echo e(asset('public/assets/img/ph-chart-eng.jpg')); ?>" class="img-fluid">
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alkaline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cheers\resources\views/cheers-alkaline.blade.php ENDPATH**/ ?>