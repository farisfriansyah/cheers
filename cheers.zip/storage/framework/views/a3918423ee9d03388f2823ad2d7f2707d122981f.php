<script src="<?php echo e(asset('public/assets/vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/aos/dist/aos.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/fullcalendar/main.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/mixitup/dist/mixitup.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/owlcarousel/dist/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/script.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\cheers\resources\views/includes/javalist.blade.php ENDPATH**/ ?>