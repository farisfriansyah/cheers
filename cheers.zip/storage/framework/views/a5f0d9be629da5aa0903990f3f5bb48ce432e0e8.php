

<?php $__env->startSection('content'); ?>

<section id="cheers-event">
    <div class="myfullpad">
        <div class="row g-1">
            <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-6 col-sm-12 event-leftsection">
                <div id="eventCalendar"></div>
            </div>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-12 event-rightsection">
            <h3 class="titleof-category">Event List</h3>

            <div class="row g-1">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card eventstd-card mb-1">
                        <div class="row g-0">
                            <div class="col-3">
                                <img src="<?php echo e($baseurl.$ev['image']); ?>" class="card-img rounded">
                            </div>

                            <div class="col-9">
                                <div class="card-body">
                                    <div class="title-section text-left">
                                        <a href="<?php echo e(url('event/view/'.$ev['id'])); ?>"><h5><?php echo e($ev['name']); ?></h5></a>
                                        <span class="metaeventstd"><i class="fad fa-calendar-day"></i> 
                                            <?php echo e(strftime("%d %B %Y", strtotime($ev['startdate'])).' - '.strftime("%d %B %Y", strtotime($ev['enddate']))); ?>

                                        </span>
                                        <span class="metaeventstd"><i class="fad fa-map-marker-alt"></i> <?php echo e($ev['lokasi']); ?></span> 
                                        <p><?php echo $ev['description']; ?></p>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            </div>
        </div>
    </div>
</section>

<section id="cheers-promopart">
    <div class="myfullpad">
        <div class="text-left">
            <h3>Promo</h3>
            <hr class="cheers-separator">
        
        </div>
        <div class="row mb-5">
            <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-6 order-md-2 promo-part">
                <a href="#">
                    <div class="card card-promo">
                        <div class="row g-0">
                            <div class="col-md-5">
                                <div class="cardpromo-img">
                                    <div class="promoicon">
                                        <div id="burst-12"><div><i class="fad fa-percentage"></i></div></div>
                                    </div>
                                    <img src="<?php echo e($baseurl.$pr['image']); ?>" class="promo-img rounded" alt="<?php echo e($pr['name']); ?>">
                                </div>
                               
                            </div>
                            <div class="col-md-7">
                                <div class="card-body">
                                    <h6 class="card-title"><?php echo e($pr['name']); ?></h6>
                                    <p class="card-text"><?php echo $pr['description']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
        var URL = "<?php echo e(url('/')); ?>";

        var calendarEl = document.getElementById('eventCalendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            headerToolbar: {
                left: 'prev,next title',
                center: '',
                right: 'today dayGridMonth,list'
            },
            // titleFormat: { // will produce something like "Tuesday, September 18, 2018"
            //     month: 'long',
            //     year: 'numeric',
            //     day: 'numeric'
            // },
            themeSystem: 'bootstrap',
            initialView: 'dayGridMonth',
            selectable: true,
            selectConstraint:{
                start: '00:01', 
                end: '23:59',
                allDay: false
            },
            eventConstraint:{
                start: '00:00', 
                end: '24:00', 
                allDay: false
            },
            // dateClick: function(info) {
            //     alert('clicked ' + info.dateStr);
            // },
            // select: function(info) {
            //     alert('selected ' + info.startStr + ' to ' + info.endStr);
            // },
            events: {
                type: "GET",
                url: URL+'/api/eventCalendar',
                data: {_token: CSRF_TOKEN},
                dataType: 'json'
            },
        });
        calendar.render();
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appdef', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cheers\resources\views/event/index.blade.php ENDPATH**/ ?>