

<?php $__env->startSection('content'); ?>

<section id="cheers-blogview" class="blogcomponent">
    <div class="myfullpad">
        <div class="row g-2">
            <div class="col-xxl-9 col-xl-9 col-lg-9 col-md-6 col-sm-12">
                <article>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="title-section text-left">
                        
                        <h3 class="titleof-category"><?php echo e($dt['title_'.$locale]); ?></h3>
                        <span class="metablog"><i class="fad fa-calendar-day"></i> <?php echo e(strftime("%d %B %Y", strtotime($dt['created_at']))); ?></span> 
                        <span class="metablog"><i class="fad fa-user"></i> Admin</span>
                        <span class="metablog"><i class="fad fa-hourglass"></i> <?php echo e($dt['duration']); ?> min read</span>
                    </div>

                    <div class="blog-detail">
                        <img src="<?php echo e($baseurl.$dt['image']); ?>" class="img-fluid bloghead-img">

                        <div class="text-blog">
                           <?php echo $dt['content_'.$locale]; ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </article>
            </div>
            <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-12 sticky-rightcontent">
                <div class="sticky-content">
                    <h3 class="titleof-category">Trending</h3>

                    <div class="row g-1">
                        <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <?php $trd_=1; ?>
                            <?php $__currentLoopData = $trending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="card blog-card mb-1">
                                <div class="row g-0">
                                    <div class="col-2">
                                        <h3 class="number-listblog">0<?php echo e($trd_); ?></h3>
                                    </div>

                                    <div class="col-10">
                                        <div class="card-body">
                                            <div class="title-section text-left">
                                                <a href="<?php echo e(url('blog/view/'.$trd['url'].'/'.$trd['id'])); ?>"><h5><?php echo e($trd['title_'.$locale]); ?></h5></a>
                                                <span class="metablog"><i class="fad fa-calendar-day"></i> <?php echo e(strftime("%d %B %Y", strtotime($trd['created_at']))); ?></span> 
                                                <span class="metablog"><i class="fad fa-user"></i> Admin</span>
                                                <span class="metablog"><i class="fad fa-hourglass"></i> <?php echo e($trd['duration']); ?>min read</span>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <?php $trd_++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appdef', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cheers\resources\views/blog/view.blade.php ENDPATH**/ ?>